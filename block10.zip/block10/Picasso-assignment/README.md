# Picasso-assignment
Fullstack block10 workshop
Created Purchase Form with text input, radio buttons, hover, nth child designation, & circular submit button;
For artwork, used flex box and z-index.
